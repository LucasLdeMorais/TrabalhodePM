package controladores;

public class CurriculoControlador {

}
