package modelos;

import java.util.ArrayList;

public class Curriculo {
	
	private int semestresCursados;
	private ArrayList<String> premios;
	private ArrayList<String> artigosTres;
	private ArrayList<String> artigosUm;
	private ArrayList<String> eventos;
	private ArrayList<String> vinculoUnirio;
	

}
