package modelos;

public class Aluno {
		
	private String nome;
	private Curriculo curriculo;
}
