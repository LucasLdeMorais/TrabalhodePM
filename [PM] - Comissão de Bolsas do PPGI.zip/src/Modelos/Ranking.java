package modelos;

import java.util.ArrayList;


public class Ranking {
	private ArrayList<Aluno> alunos;

}
